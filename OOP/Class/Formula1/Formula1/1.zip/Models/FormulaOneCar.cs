﻿using Formula1.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Formula1.Models
{
    public abstract class FormulaOneCar : IFormulaOneCar
    {
        private string model;
        private int horsepower;
        private double engineDisplacement;

        protected FormulaOneCar(string model, int horsepower, double engineDisplacement)
        {
            this.Model = model;
            this.Horsepower = horsepower;
            this.EngineDisplacement = engineDisplacement;
        }

        public string Model { get => model; private set => model = value; }

        public int Horsepower { get => horsepower; private set => horsepower = value; }

        public double EngineDisplacement { get => engineDisplacement; private set => engineDisplacement = value; }

        public double RaceScoreCalculator(int laps)
        {
            throw new NotImplementedException();
        }
    }
}
