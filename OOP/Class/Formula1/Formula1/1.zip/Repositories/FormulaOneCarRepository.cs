﻿using Formula1.Models.Contracts;
using Formula1.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Formula1.Repositories
{
    public class FormulaOneCarRepository : IRepository<IFormulaOneCar>
    {
        private readonly List<IFormulaOneCar> models;

        public FormulaOneCarRepository()
        {
            models = new List<IFormulaOneCar>();
        }
        public IReadOnlyCollection<IFormulaOneCar> Models => this.models;

        public void Add(IFormulaOneCar model)
        {
            throw new NotImplementedException();
        }

        public IFormulaOneCar FindByName(string name)
        {
            throw new NotImplementedException();
        }

        public bool Remove(IFormulaOneCar model)
        {
            throw new NotImplementedException();
        }
    }
}
